# Project: p5
# Submitter: hhess3
# Partner: None
# Hours: 3

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

class UserPredictor:
    def __init__(self):
        self.classifier = RandomForestClassifier()
        self.preprocessor = None  
        
    def add_log_features(self, users, logs):
        total_seconds = logs.groupby('user_id')['seconds'].sum().reset_index()
        users = pd.merge(users, total_seconds, on='user_id', how='left')
        users['seconds'].fillna(0, inplace=True)
        return users

    def fit(self, users, logs, y):
        users_with_logs = self.add_log_features(users, logs)
        X = users_with_logs[['age', 'past_purchase_amt', 'badge', 'seconds']]
        y = y["y"]
        
        badge_categories = users_with_logs['badge'].unique()
        self.preprocessor = ColumnTransformer(
            transformers=[
                ('numeric', StandardScaler(), ['age', 'past_purchase_amt', 'seconds']),
                ('categorical', OneHotEncoder(handle_unknown='ignore'), ['badge'])
            ],
            remainder='passthrough'
        )

        X_processed = self.preprocessor.fit_transform(X)
        
        pipeline = Pipeline([
            ('classifier', self.classifier)
        ])
        scores = cross_val_score(pipeline, X_processed, y)
        
        self.classifier.fit(X_processed, y)

    def predict(self, users, logs):
        users_with_logs = self.add_log_features(users, logs)
        X_pred = users_with_logs[['age', 'past_purchase_amt', 'badge', 'seconds']]

        X_pred_processed = self.preprocessor.transform(X_pred)

        predictions = self.classifier.predict(X_pred_processed)
        return predictions

